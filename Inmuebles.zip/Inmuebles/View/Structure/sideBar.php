<div class="sidebar close">
    <div class="logo-details">
        <img src="img/SFY.png" class="logoPanel">
        <span class="logo_name" class="mt-5">Real State</span>
    </div>
    <ul class="nav-links">
        <li>
            <a href="Panel.php?Page=Home">
                <i class='bx bx-grid-alt'></i>
                <span class="link_name">Comprar</span>
            </a>
            <ul class="sub-menu blank">
                <li><a class="link_name" href="Panel.php?Page=Home">Comprar</a></li>
            </ul>
        </li>
        <!-- <li>
            <div class="iocn-link">
                <a href="#">
                    <i class='bx bxs-hot'></i>
                    <span class="link_name">Horno</span>
                </a>
                <i class='bx bxs-chevron-down arrow'></i>
            </div>
            <ul class="sub-menu">
                <li><a class="link_name" href="#">Horno</a></li>
                <li><a href="#">Lasañas</a></li>
                <li><a href="#">Canelones</a></li>
                <li><a href="#">Gratinados</a></li>
                <li><a href="#">Ver Todo</a></li>
            </ul>
        </li> -->
        <li>
            <div class="profile-details">
                <div class="profile-content">
                    <img src="img/SFY.png" alt="profileImg" class="w-12 h-12">
                </div>
                <div class="name-job">
                    <div class="profile_name">SFY</div>
                    <div class="job">international</div>
                </div>
                
                <a href="/Controller/Logout.php">
                <i class='bx bx-log-out'></i>
                </a>

            </div>
        </li>
    </ul>
</div>