<div class="sidebar close">
    <div class="logo-details">
        <img src="img/SFY.png" class="logoPanel">
        <span class="logo_name" class="mt-5">Real State</span>
    </div>
    <ul class="nav-links">
        <li>
            <a href="View/Home.php?Page=Home">
            <i class='bx bxs-home-alt-2' style='color:#e6b87c'  ></i>
                <span class="link_name">Home</span>
            </a>
        </li>

        <li>
            <a href="View/Users.php">
            <i class='bx bxs-user-circle' style="color:#e6b87c"></i>
            <span class="link_name">Users</span>
            </a>
        </li>

        <li>
            <a href="View/Neighborhood.php">
            <i class='bx bxs-buildings' style="color:#e6b87c"></i>
                <span class="link_name">Neighborhood</span>
            </a>
        </li>

        <li>
            <a href="View/Property.php">
            <i class='bx bxs-school' style="color:#e6b87c"></i>
                <span class="link_name">Property</span>
            </a>
        </li>

        <li>
            <a href="View/Sale.php">
            <i class='bx bx-cart-add' style='color:#e6b87c' ></i>
                <span class="link_name">Sale</span>
            </a>
        </li>

        <!-- <li>
            <div class="iocn-link">
                <a href="#">
                    <i class='bx bxs-hot'></i>
                    <span class="link_name">Horno</span>
                </a>
                <i class='bx bxs-chevron-down arrow'></i>
            </div>
            <ul class="sub-menu">
                <li><a class="link_name" href="#">Horno</a></li>
                <li><a href="#">Lasañas</a></li>
                <li><a href="#">Canelones</a></li>
                <li><a href="#">Gratinados</a></li>
                <li><a href="#">Ver Todo</a></li>
            </ul>
        </li> -->
        <li>
            <div class="profile-details">
                <div class="profile-content">
                    <img src="img/SFY.png" alt="profileImg" class="w-12 h-12">
                </div>
                <div class="name-job">
                    <div class="profile_name">SFY</div>
                    <div class="job">international</div>
                </div>
                
                <a href="/Controller/Logout.php">
                <i class='bx bx-log-out'></i>
                </a>

            </div>
        </li>
    </ul>
</div>