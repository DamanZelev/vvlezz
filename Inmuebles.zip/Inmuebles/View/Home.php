<h1> 👌 </h1>

<span>Ya funciona todo el login al 100, registra los usuarios y no deja que los duplique, también tira el mensajito de exito y si ya está en la base de datos tambien lo marca como que ya está registrado</span>
