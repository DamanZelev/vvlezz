<!DOCTYPE html>
<html lang="en">
<?php require_once("Structure/Head.php"); ?>

<body>
<?php require_once("Structure/sideBar.php");?>
    
</body>
</html>