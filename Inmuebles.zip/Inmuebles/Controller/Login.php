 <?php
 session_start();
require_once(__DIR__ . '/../Model/Login.php');


if (isset($_POST['Create'])) {

    $user = new User($_POST['id'], $_POST['name'], $_POST['adress'], $_POST['phone'], $_POST['email'], $_POST['password'], $_POST['rol']);

    $user->insert();
    exit();
}

if (isset($_POST['Sign_In'])) {
    $user = new User('', '', '', '', $_POST['email'], $_POST['password'], '');
    if ($user->authenticate($_POST['email'], $_POST['password'])) {
        // Redirige al usuario autenticado a la página deseada
        header("Location: ./Panel.php");
        exit();
    } else {
        // La autenticación falló, maneja según tus necesidades
        echo "Error de autenticación.";
    }
}

?>
