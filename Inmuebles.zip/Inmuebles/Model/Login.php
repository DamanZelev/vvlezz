 <?php


 session_start(); 
 ob_clean();
    class User
    {
        private $id;
        private $name;
        private $address;
        private $phone;
        private $email;
        private $password;
        private $rol;
        private $isActive;
        private $isLoggedIn;

        // Constructor
        public function __construct($id, $name, $address,   $phone, $email, $password, $rol)
        {
            $this->id = $id;
            $this->name = $name;
            $this->address = $address;
            $this->phone = $phone;
            $this->email = $email;
            $this->password = $password;
            $this->rol = $rol;
            $this->isActive = true;
            $this->isLoggedIn =false;
        }


        // Función para ver si el usuario existe
        public function userExists($email)
        {
            $jsonFile = "../Json/Users.json";
    

            if (!file_exists($jsonFile)) {
                return false; // 
            }
    

            $jsonContent = file_get_contents($jsonFile);
    

            $users = json_decode($jsonContent, true);
    
            // Verificar si el usuario existe en el array
            foreach ($users as $user) {
                if ($user['email'] === $email) {
                    return true;
                }
            }
    
            return false; 
        }
    
        //Función para autenticar el fucking plebeyo
                public function authenticate($email, $password)
        {
            $jsonFile = __DIR__ . '/../Json/Users.json';
        
            $jsonContent = file_get_contents($jsonFile);
        
            $users = json_decode($jsonContent, true);
        
            foreach ($users as $user) {
                if ($user['email'] === $email && $user['password'] === $password) {
                    $this->isLoggedIn = true;
                    return true; 
                }
            }
        
            return false; 
        }

        //Función para insertar el usuario
        public function insert()
        {
            $jsonFile = '../Json/Users.json';
        
            
            if ($this->userExists($this->email)) {
                echo "El usuario ya existe. No se ha insertado.";
                flush();
                return; 
            }

        
           
            $jsonContent = file_get_contents($jsonFile);
        
    
            $users = json_decode($jsonContent, true);
  
            $userData = array(
                'id' => $this->id,
                'name' => $this->name,
                'address' => $this->address,
                'phone' => $this->phone,
                'email' => $this->email,
                'password' => $this->password,
                'rol' => $this->rol,
                'isActive' => $this->isActive
            );
        

            $users[] = $userData;

            $jsonUpdated = json_encode($users, JSON_PRETTY_PRINT);

            file_put_contents($jsonFile, $jsonUpdated);
        

            header("Location: ../Login.php");

            $this->authenticate($this->email, $this->password);
        }
        



    }

?>