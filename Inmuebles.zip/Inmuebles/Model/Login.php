 <?php
 session_start(); 
 ob_clean();
    class User
    {
        private $id;
        private $name;
        private $address;
        private $phone;
        private $email;
        private $password;
        private $rol;
        private $isActive;
        private $isLoggedIn;

        // Constructor
        public function __construct($id, $name, $address,   $phone, $email, $password, $rol)
        {
            $this->id = $id;
            $this->name = $name;
            $this->address = $address;
            $this->phone = $phone;
            $this->email = $email;
            $this->password = $password;
            $this->rol = $rol;
            $this->isActive = true;
            $this->isLoggedIn =false;
        }


        // Fundación para ver si el usuario existe
        public function userExists($email)
        {
            $jsonFile = "../Json/Users.json";
    
            // Verificar si el archivo JSON existe
            if (!file_exists($jsonFile)) {
                return false; // El archivo no existe, por lo tanto, el usuario no puede existir
            }
    
            // Obtener el contenido del archivo JSON
            $jsonContent = file_get_contents($jsonFile);
    
            // Decodificar el contenido JSON a un array asociativo
            $users = json_decode($jsonContent, true);
    
            // Verificar si el usuario existe en el array
            foreach ($users as $user) {
                if ($user['email'] === $email) {
                    return true; // El usuario ya existe
                }
            }
    
            return false; // El usuario no existe
        }
    
        //Función para autenticar el fucking plebeyo
                public function authenticate($email, $password)
        {
            $jsonFile = __DIR__ . '/../Json/Users.json';
        
            $jsonContent = file_get_contents($jsonFile);
        
            $users = json_decode($jsonContent, true);
        
            foreach ($users as $user) {
                if ($user['email'] === $email && $user['password'] === $password) {
                    $this->isLoggedIn = true;
                    return true; // Autenticación exitosa
                }
            }
        
            return false; // Autenticación fallida
        }

        //Función para insertar el usuario
        public function insert()
        {
            $jsonFile = '../Json/Users.json';
        
            // Verificar si el usuario ya existe antes de insertarlo
            if ($this->userExists($this->email)) {
                echo "El usuario ya existe. No se ha insertado.";
                flush();
                return; // No inserta si el usuario ya existe
            }

        
            // Obtener el contenido actual del archivo JSON
            $jsonContent = file_get_contents($jsonFile);
        
            // Decodificar el contenido JSON a un array asociativo
            $users = json_decode($jsonContent, true);
        
            // Crear el array con los datos del usuario
            $userData = array(
                'id' => $this->id,
                'name' => $this->name,
                'address' => $this->address,
                'phone' => $this->phone,
                'email' => $this->email,
                'password' => $this->password,
                'rol' => $this->rol,
                'isActive' => $this->isActive
            );
        
            // Agregar el usuario al array de usuarios
            $users[] = $userData;
        
            // Codificar el array a formato JSON
            $jsonUpdated = json_encode($users, JSON_PRETTY_PRINT);
        
            // Escribir el JSON actualizado de vuelta al archivo
            file_put_contents($jsonFile, $jsonUpdated);
        

            header("Location: ../Login.php");

            $this->authenticate($this->email, $this->password);
        }
        



    }
?>