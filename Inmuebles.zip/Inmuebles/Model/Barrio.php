 <?php
//SECCIÓN PARA "BARRIO"
class Barrio {

    // Atributos
    private $Nombre;
    private $Ciudad;
    private $Dpto;
    private $usuario_registro;

    // Constructor
    public function __construct($nombre, $ciudad, $dpto, $usuario_registro) {
        $this->Nombre = $nombre;
        $this->Ciudad = $ciudad;
        $this->Dpto = $dpto;
        $this->usuario_registro = $usuario_registro;
    }

    // Métodos

    public function insertar() {
        // Lógica para insertar un nuevo registro en la base de datos
        $jsonFile = '../Json/Barrios.json';

        if(!file_exists($jsonFile)){
            return false;
        }

        $jsonContent = file_get_contents($jsonFile);

        $barrios = json_decode($jsonContent, true);

        $new_barrio = array(
            'Nombre' => $this->Nombre,
            'Ciudad' => $this->Ciudad,
            'Dpto' => $this->Dpto,
            'usuario_registro' => $this->usuario_registro
        );

        $barrios[] = $new_barrio;

        $jsonUpdated = json_encode($barrios, JSON_PRETTY_PRINT);

        file_put_contents($jsonFile, $jsonUpdated);

        echo "Registro insertado correctamente en el archivo JSON.";
    }

    public function editar() {
        // Lógica para editar un registro existente en la base de datos
    }

    public function eliminar() {
        // Lógica para eliminar un registro de la base de datos
    }

    public function consultar() {
        // Lógica para consultar información de la base de datos
    }
}
?>