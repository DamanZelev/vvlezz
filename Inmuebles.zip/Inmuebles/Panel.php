<!DOCTYPE html>
<html lang="en">
<?php require_once("View/Structure/Head.php")  ?>

<body>
    <?php require_once "View/Structure/sideBar.php"; ?>
    <section class="home-section">
        <div class="home-content">
            <i class='bx bx-menu' style=" color:gray;"></i>
        </div>
        <?php
        if (isset($_GET["Page"])) {
            switch ($_GET['Page']) {
                case "Home":
                    require_once("View/Home.php");
                    break;
            }
        }
        ?>
    </section>
    <?php require_once("View/Structure/Scripts.php"); ?>
</body>
</html>